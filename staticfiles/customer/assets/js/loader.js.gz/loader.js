/*=====================
    loader js
   ==========================*/

setTimeout(() => {
  const loader = document.querySelector(".skeleton-loader");
  loader.style.display = "none";
}, 4000);
